package com.example.proyecto

    class User (id: String,
                nombre: String,
                dia: String,
                nivel: String,
                cantidad: String){

        val id = id
        val nombre = nombre
        val dia = dia
        val nivel = nivel
        val cantidad = cantidad
    }
